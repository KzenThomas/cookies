window.onload = function() {
    retrieveCookies()
}

function retrieveCookies() {
   var voornaam = getCookie("voornaam")
   var naam = getCookie("naam");
   var email = getCookie("email");
   var geboortedatum = getCookie("geboortedatum");
   var datumAfspraak = getCookie("datumAfspraak");
   var uurAfspraak = getCookie("uurAfspraak");
   confirm(voornaam, naam, email, geboortedatum, datumAfspraak, uurAfspraak)
}

function controleerGegevens() {
    var voornaam = document.forms["form"]["voornaam"].value
    var naam = document.forms["form"]["naam"].value
    var email = document.forms["form"]["email"].value
    var geboortedatum = document.forms["form"]["geboortedatum"].value
    var datumAfspraak = document.forms["form"]["datumAfspraak"].value
    var uurAfspraak = document.forms["form"]["uurAfspraak"].value

    var errors = 0;
    
    controleervoornaam(voornaam);
    controleerNaam(naam);
    controleerEmail(email);
    controleergeboortedatum(geboortedatum);
    controleerdatumAfspraak(datumAfspraak);
    controleeruurAfspraak(uurAfspraak);
    setCookie(cname, cvalue);
    
    if (errors == 0){
        setCookie("voornaam", voornaam)
        setCookie("naam", naam)
        setCookie("email", email)
        setCookie("geboortedatum", geboortedatum)
        setCookie("datumAfspraak", datumAfspraak)
        setCookie("uurAfspraak" , uurAfspraak)
        confirm(voornaam, naam, email, geboortedatum, datumAfspraak, uurAfspraak)
    }
}   

function confirm(voornaam, naam, email, geboortedatum, datumAfspraak, uurAfspraak){
	document.getElementById("confirm").style.display="block"
        document.getElementById("name").innerHTML = naam + " " + voornaam;
        document.getElementById("e-mail").innerHTML = email;
        document.getElementById("bdayfull").innerHTML = geboortedatum;
        document.getElementById("appdate").innerHTML = datumAfspraak;
        document.getElementById("apphourhour").innerHTML = uurAfspraak;
}


function controleervoornaam(voornaam) {
    if (voornaam == "") {
        alert("Voornaam moet ingevuld zijn")
        errors++
    } 
}

function controleerNaam(naam) {
    if (naam == "") {
        alert("naam moet ingevuld zijn")
        errors++
    }
}

function controleerEmail(email) {
    if (!email.includes('@')) {
        alert("In een email zit geen @-teken!")
        errors++
    }
}

function controleergeboortedatum(geboortedatum) {
    if (new Date(geboortedatum) > Date.now()){
        alert("De geboortedatum moet in het verleden liggen")
        errors++
    }
}

function controleerdatumAfspraak(datumAfspraak) {
    if (new Date(datumAfspraak) < Date.now()) {
        alert("De datum van de afspraak mag niet in het verleden liggen")
        errors++
    }
}

function controleeruurAfspraak(uurAfspraak) {
	console.log(uurAfspraak)
    if (uurAfspraak < 6 || uurAfspraak > 21) {
        alert("De aspraak moet tussen 6 u en 21 u liggen")
        errors++
    }
}

function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for(var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function setCookie(cname, cvalue) {
document.cookie = cname + "=" + cvalue + ";";
}
